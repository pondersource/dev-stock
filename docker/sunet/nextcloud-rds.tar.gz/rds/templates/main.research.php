<?php
script('rds', array("vue", "app"));
style('rds', array('style'));
?>

<noscript>
    <strong>
        We're sorry but rds-web doesn't work properly without JavaScript enabled. Please enable it to
        continue.
    </strong>
</noscript>
<div id="owncloud-rds-app">
    <div id="app"></div>
</div>
