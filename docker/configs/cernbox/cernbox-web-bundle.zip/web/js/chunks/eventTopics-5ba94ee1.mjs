var l=(e=>(e.open="sidebar.open",e.close="sidebar.close",e.toggle="sidebar.toggle",e.openWithPanel="sidebar.openWithPanel",e.setActivePanel="sidebar.setActivePanel",e))(l||{});export{l as S};
