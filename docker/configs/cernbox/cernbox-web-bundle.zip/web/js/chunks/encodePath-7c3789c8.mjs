const n=(e="")=>e.split("/").map(encodeURIComponent).join("/");export{n as e};
