const t=e=>(e||"").split("_")[0];export{t as g};
