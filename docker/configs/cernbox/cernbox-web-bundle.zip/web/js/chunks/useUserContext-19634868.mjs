import{l as e}from"./vendor-d4784ec7.mjs";const s=({store:t})=>e(()=>t.getters["runtime/auth/isUserContextReady"]);export{s as u};
